class Config {
  static String configUrl = 'https://phlwinphilwinapps.space/phlwin';
  static String configText = 'sorry please watch game now';
  static String bundleId = 'com.game-balls731.app';
  static String appodealKey =
      'c1c26b74676308f2ac73467e1ce7ec0bf172b1c4dbc67b87';
  static bool testMode = true;
}
